// Base URL for the Storypath RESTful API
const API_BASE_URL = 'https://0b5ff8b0.uqcloud.net/api';

// JWT token for authorization, replace with your actual token from My Grades in Blackboard
const JWT_TOKEN = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoic3R1ZGVudCIsInVzZXJuYW1lIjoiczQ4Mjg0MTIifQ.zAJnYyZIOsYasYpID7f9kZaJYMUe3hEnYdzr3-o9wqo';

// Your UQ student username, used for row-level security to retrieve your records
const USERNAME = 's4828412';

/**
 * Helper function to handle API requests.
 * It sets the Authorization token and optionally includes the request body.
 * 
 * @param {string} endpoint - The API endpoint to call.
 * @param {string} [method='GET'] - The HTTP method to use (GET, POST, PATCH).
 * @param {object} [body=null] - The request body to send, typically for POST or PATCH.
 * @returns {Promise<object>} - The JSON response from the API.
 * @throws Will throw an error if the HTTP response is not OK.
 */
async function apiRequest(endpoint, method = 'GET', body = null) {
  const options = {
    method, // Set the HTTP method (GET, POST, PATCH)
    headers: {
      'Content-Type': 'application/json', // Indicate that we are sending JSON data
      'Authorization': `Bearer ${JWT_TOKEN}` // Include the JWT token for authentication
    },
  };

  // If the method is POST or PATCH, we want the response to include the full representation
  if (method === 'POST' || method === 'PATCH') {
    options.headers['Prefer'] = 'return=representation';
  }

  // If a body is provided, add it to the request and include the username
  if (body) {
    options.body = JSON.stringify({ ...body, username: USERNAME });
  }

  // Make the API request and check if the response is OK
  const response = await fetch(`${API_BASE_URL}${endpoint}`, options);
  
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  
  // Return the response as a JSON object
  return response.json();
}

/**
 * Function to insert a new location into the database.
 * @param {object} location - The location data to insert.
 * @returns {Promise<object>} - The created location object returned by the API.
 */
export async function createLocation(location) {
  return apiRequest("/location", "POST", location);
}

/**
 * Function to list all locations associated with a project.
 * @param {string} projectId - The ID of the project to retrieve locations for.
 * @returns {Promise<Array>} - An array of location objects.
 */
export async function getLocationsByProject(projectId) {
  return apiRequest(`/location?project_id=eq.${projectId}`);
}

/**
 * Function to get a single location by its ID.
 * @param {string} id - The ID of the location to retrieve.
 * @returns {Promise<object>} - The location object matching the ID.
 */
export async function getLocation(id) {
  return apiRequest(`/location?id=eq.${id}`);
}

/**
 * Function to update a location by its ID.
 * @param {string} id - The ID of the location to update.
 * @param {object} updatedData - The updated location data.
 * @returns {Promise<object>} - The updated location object returned by the API.
 */
export async function updateLocation(id, updatedData) {
  return apiRequest(`/location?id=eq.${id}`, "PATCH", updatedData);
}

/**
 * Function to delete a location by its ID.
 * @param {string} id - The ID of the location to delete.
 * @returns {Promise<void>} - No return value on success.
 */
export async function deleteLocation(id) {
  return apiRequest(`/location?id=eq.${id}`, "DELETE");
}

/**
 * Function to retrieve content associated with a specific location.
 * @param {string} locationId - The ID of the location to retrieve content for.
 * @returns {Promise<Array>} - An array of location content objects.
 */
export async function getLocationContent(locationId) {
  return apiRequest(`/location_content?location_id=eq.${locationId}`);
}

/**
 * Function to add content to a specific location.
 * @param {object} locationContent - The location content data to insert.
 * @returns {Promise<object>} - The created location content object returned by the API.
 */
export async function createLocationContent(locationContent) {
  return apiRequest("/location_content", "POST", locationContent);
}

/**
 * Function to delete location content by its ID.
 * @param {string} contentId - The ID of the location content to delete.
 * @returns {Promise<void>} - No return value on success.
 */
export async function deleteLocationContent(contentId) {
  return apiRequest(`/location_content?id=eq.${contentId}`, "DELETE");
}