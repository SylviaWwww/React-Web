import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { getLocationContent, createLocationContent, deleteLocationContent } from '../api/LocationApi';

function LocationContent() {
  const [contents, setContents] = useState([]);
  const { projectId, locationId } = useParams();
  const [newContent, setNewContent] = useState({
    content_order: 0,
    content_type: 'text',
    content_body: '',
  });

  useEffect(() => {
    async function fetchContents() {
      const contentData = await getLocationContent(locationId);
      setContents(contentData);
    }
    fetchContents();
  }, [locationId]);

  const handleDelete = async (contentId) => {
    await deleteLocationContent(contentId);
    setContents(contents.filter(content => content.id !== contentId));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await createLocationContent({ ...newContent, location_id: locationId });
    setNewContent({ content_order: 0, content_type: 'text', content_body: '' });
    const contentData = await getLocationContent(locationId);
    setContents(contentData);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewContent({ ...newContent, [name]: value });
  };

  return (
    <div className="container">
      <h2>Location Content</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="content_order">Content Order</label>
          <input
            type="number"
            className="form-control"
            id="content_order"
            name="content_order"
            value={newContent.content_order}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="content_type">Content Type</label>
          <select
            className="form-control"
            id="content_type"
            name="content_type"
            value={newContent.content_type}
            onChange={handleChange}
          >
            <option value="text">Text</option>
            <option value="image">Image</option>
            <option value="video">Video</option>
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="content_body">Content Body</label>
          <textarea
            className="form-control"
            id="content_body"
            name="content_body"
            value={newContent.content_body}
            onChange={handleChange}
            required
          ></textarea>
        </div>
        <button type="submit" className="btn btn-primary">Add Content</button>
      </form>

      <ul className="list-group mt-3">
        {contents.map(content => (
          <li className="list-group-item d-flex justify-content-between align-items-center" key={content.id}>
            <span>{content.content_body} (Order: {content.content_order})</span>
            <button className="btn btn-danger btn-sm" onClick={() => handleDelete(content.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default LocationContent;
