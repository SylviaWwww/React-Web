import React from "react";

function Footer() {
  return (
    <footer className="bg-dark text-white text-center text-lg-start fixed-bottom">
      {/* Footer */}
      <div className="text-center p-3 bg-secondary">
        © 2024 StoryPath. All rights reserved.
      </div>
    </footer>
  );
}

export default Footer;
