import React, { useState, useEffect } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import { getLocationsByProject } from "../api/LocationApi";
import { getProject } from "../api/ProjectApi";

function PreviewPage() {
  const { projectId } = useParams();
  const [locations, setLocations] = useState([]);
  const [project, setProject] = useState([]);
  const [selectedLocation, setSelectedLocation] = useState("Homescreen");
  const [locationContent, setLocationContent] = useState("");
  const [totalPoints, setTotalPoints] = useState(0);
  const [totalLocations, setTotalLocations] = useState(0);
  const [error, setError] = useState(null); // store error message
  const navigate = useNavigate();
  const location = useLocation();

  // Fetch project title and locations
  useEffect(() => {
    async function fetchData() {
      try {
        // Fetch project title
        const projectData = await getProject(projectId);
        if (projectData && projectData.length > 0) {
          setProject(projectData[0]);
        } else {
          throw new Error("Project not found");
        }

        // Fetch locations
        const locationsData = await getLocationsByProject(projectId);
        if (locationsData) {
          setLocations(locationsData);

          // Calculate total points and number of locations
          const pointsSum = locationsData.reduce(
            (acc, loc) => acc + loc.score_points,
            0
          );
          setTotalPoints(pointsSum);
          setTotalLocations(locationsData.length);
        } else {
          throw new Error("Locations not found");
        }
      } catch (err) {
        console.error("Error fetching data:", err);
        setError(err.message); // Set error state
      }
    }

    fetchData();
  }, [projectId]);

  // Handle location change in the dropdown menu
  const handleLocationChange = (e) => {
    const selected = e.target.value;
    setSelectedLocation(selected);

    if (selected === "Homescreen") {
      setLocationContent("");
    } else {
      const selectedLoc = locations.find(
        (loc) => loc.location_name === selected
      );

      setLocationContent(selectedLoc ? selectedLoc.location_content : "");
    }
  };

  // display points based on scoring type
  const renderPoints = () => {
    if (project.participant_scoring === "Number of Scanned QR Codes") {
      return (
        <div
          style={{
            backgroundColor: "#c4adae",
            width: "8vw",
            padding: "1vw",
            borderRadius: "10px",
          }}
        >
          <p>Points</p>
          <p>0 / {totalPoints}</p> {/* total points from all locations */}
        </div>
      );
    } else if (project.participant_scoring === "Time to Complete") {
      return (
        <div
          style={{
            backgroundColor: "#c4adae",
            width: "8vw",
            padding: "1vw",
            borderRadius: "10px",
          }}
        >
          <p>Total Time</p>
          <p>00:00:00</p> {/* static time */}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="container">
      <h1 className="preview-title">{project.title} - Preview</h1>

      {/* dropdown to select location */}
      <div className="form-group">
        <label htmlFor="locationSelect">
          Change Locations to Test Scoring:
        </label>
        <select
          id="locationSelect"
          className="form-control"
          value={selectedLocation}
          onChange={handleLocationChange}
        >
          <option value="Homescreen">Homescreen</option>
          {locations.map((location) => (
            <option key={location.id} value={location.location_name}>
              {location.location_name}
            </option>
          ))}
        </select>
      </div>

      {/* display based on selected location and homescreen_display */}
      <div className="card mt-4" style={mobilePreviewStyles}>
        <div className="card-body text-center">
          {selectedLocation === "Homescreen" ? (
            project.homescreen_display === "Display initial clue" ? (
              <div>
                <h5
                  className="card-title"
                  style={{
                    backgroundColor: "#b0ac92",
                    padding: "0.5vh",
                    borderRadius: "10px",
                  }}
                >
                  {project.title}
                </h5>
                <p className="card-text">Instructions</p>
                <p>{project.instructions}</p>
                <p className="card-text">Initial Clue</p>
                <p>{project.initial_clue}</p>
                <div className="d-flex justify-content-between">
                  {renderPoints()}
                  <div
                    style={{
                      backgroundColor: "#c4adae",
                      width: "8vw",
                      padding: "1vw",
                      borderRadius: "10px",
                    }}
                  >
                    <p>Locations Visited</p>
                    <p>0 / {totalLocations}</p>
                  </div>
                </div>
              </div>
            ) : project.homescreen_display === "Display all locations" ? (
              <div>
                <h5 className="card-title">All Locations</h5>
                <ul className="list-group">
                  {locations.map((location) => (
                    <li key={location.id} className="list-group-item">
                      {location.location_name}
                    </li>
                  ))}
                </ul>
                <div className="d-flex justify-content-between">
                  {renderPoints()}
                  <div
                    style={{
                      backgroundColor: "#c4adae",
                      width: "8vw",
                      padding: "1vw",
                      borderRadius: "10px",
                    }}
                  >
                    <p>Locations Visited</p>
                    <p>0 / {totalLocations}</p>
                  </div>
                </div>
              </div>
            ) : null
          ) : (
            <div>
              <h5 className="card-title">{selectedLocation}</h5>
              {locations.find((loc) => loc.location_name === selectedLocation)
                ?.clue && (
                <div className="card-text">
                  <strong>Clue:</strong>{" "}
                  {
                    locations.find(
                      (loc) => loc.location_name === selectedLocation
                    ).clue
                  }
                </div>
              )}
              {/* Render the rich content */}
              <div
                className="card-text"
                // generated from chatGPT 4o
                dangerouslySetInnerHTML={{ __html: locationContent }}
              ></div>
              <div className="d-flex justify-content-between">
                {renderPoints()}
                <div
                  style={{
                    backgroundColor: "#c4adae",
                    width: "8vw",
                    padding: "1vw",
                    borderRadius: "10px",
                  }}
                >
                  <p>Locations Visited</p>
                  <p>0 / {totalLocations}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

const mobilePreviewStyles = {
  width: "25vw",
  height: "65vh",
  border: "1px solid #ddd",
  borderRadius: "20px",
  padding: "20px",
  boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
  margin: "0 auto",
  overflow: "auto",
};

export default PreviewPage;
