import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  createLocation,
  getLocation,
  updateLocation,
  getLocationsByProject,
} from "../api/LocationApi";
import MapPicker from "./MapPicker";
import RichTextEditor from "./RichTextEditor";

function LocationsForm() {
  const { projectId, id } = useParams(); // get id from the url
  const [locationData, setLocationData] = useState({
    location_name: "",
    location_trigger: "Location",
    location_position: "",
    score_points: 0,
    clue: "",
    location_content: "",
    location_order: 0,
  });
  const navigate = useNavigate();

  // generated from chatGPT 4o 21-22
  const [mapCenter, setMapCenter] = useState([-27.4705, 153.026]);
  const [markerPosition, setMarkerPosition] = useState(mapCenter);

  // store error message
  const [error, setError] = useState("");

  useEffect(() => {
    if (id) {
      async function fetchLocation() {
        try {
          const existingLocation = await getLocation(id);
          setLocationData(existingLocation[0]);

          if (existingLocation[0].location_position) {
            // get latitude and longtitude without , and ()
            const position = existingLocation[0].location_position
              .replace(/[()]/g, "")
              .split(",")
              .map(Number);
            const [lat, lng] = position;
            if (!isNaN(lat) && !isNaN(lng)) {
              setMarkerPosition([lat, lng]);
            }
          }
        } catch (err) {
          setError("Failed to fetch location details.");
        }
      }
      fetchLocation();
    }
  }, [id]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    // validating form
    if (!locationData.location_name || !locationData.location_position) {
      setError("Please fill in all required fields.");
      return;
    }

    try {
      if (id) {
        await updateLocation(id, locationData);
      } else {
        const allLocations = await getLocationsByProject(projectId);

        // sort location based on location order
        const maxOrder = Math.max(
          ...allLocations.map((loc) => loc.location_order),
          0
        );
        await createLocation({
          ...locationData,
          project_id: projectId,
          location_order: maxOrder + 1,
        });
      }
      navigate(`/projects/${projectId}/locations`);
    } catch (err) {
      setError(
        "An error occurred while saving the location. Please try again."
      );
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setLocationData({ ...locationData, [name]: value });
    setError(""); // eliminating error everytime entering
  };

  const handleContentChange = (content) => {
    setLocationData({ ...locationData, location_content: content });
    setError(""); // eliminating error everytime entering
  };

  return (
    <div className="container">
      <h1>{id ? "Edit Location" : "Add Location"}</h1>
      <form onSubmit={handleSubmit}>
        {/* location name */}
        <div className="form-group">
          <label htmlFor="location_name">Location Name</label>
          <input
            type="text"
            className="form-control"
            id="location_name"
            name="location_name"
            value={locationData.location_name}
            onChange={handleChange}
            placeholder="The name of this location."
            required
          />
          <small className="form-text text-muted">
            The name of this location.
          </small>
        </div>

        {/* location trigger */}
        <div className="form-group">
          <label htmlFor="location_trigger">Location Trigger</label>
          <select
            className="form-control"
            id="location_trigger"
            name="location_trigger"
            value={locationData.location_trigger}
            onChange={handleChange}
            required
          >
            <option value="Location">Location</option>
            <option value="QR Code">QR Code</option>
            <option value="Both">Both</option>
          </select>
          <small className="form-text text-muted">
            Select how this location will be triggered (by location, QR code, or
            both).
          </small>
        </div>

        {/* select location from map */}
        <div className="form-group">
          <label htmlFor="location_picker">Select Location (Map Picker)</label>
          <MapPicker
            mapCenter={mapCenter}
            markerPosition={markerPosition}
            setMarkerPosition={setMarkerPosition}
            setLocationData={setLocationData}
            locationData={locationData}
          />
          <small className="form-text text-muted">
            Click on the map to select the location (latitude and longitude).
          </small>
        </div>

        {/* latitude and longtitude */}
        <div className="form-group">
          <label htmlFor="location_position">
            Location Position (lat, long)
          </label>
          <input
            type="text"
            className="form-control"
            id="location_position"
            name="location_position"
            value={locationData.location_position}
            onChange={handleChange}
            placeholder="Enter the latitude and longitude for this location."
            required
          />
          <small className="form-text text-muted">
            Enter the latitude and longitude for this location.
          </small>
        </div>

        {/* set the points */}
        <div className="form-group">
          <label htmlFor="score_points">Points for Reaching Location</label>
          <input
            type="number"
            className="form-control"
            id="score_points"
            name="score_points"
            value={locationData.score_points}
            onChange={handleChange}
            placeholder="Specify the number of points participants earn by reaching this location."
            required
          />
          <small className="form-text text-muted">
            Specify the number of points participants earn by reaching this
            location.
          </small>
        </div>

        {/* set the clue */}
        <div className="form-group">
          <label htmlFor="clue">Clue</label>
          <input
            type="text"
            className="form-control"
            id="clue"
            name="clue"
            value={locationData.clue}
            onChange={handleChange}
            placeholder="Enter the clue that leads to the next location."
            required
          />
          <small className="form-text text-muted">
            Enter the clue that leads to the next location.
          </small>
        </div>

        {/* rich text editor */}
        <div className="form-group">
          <label htmlFor="location_content">Location Content</label>
          <RichTextEditor
            value={locationData.location_content}
            onChange={handleContentChange}
          />
          <small className="form-text text-muted">
            Provide additional content that will be displayed when participants
            reach this location.
          </small>
        </div>

        <button type="submit" className="btn btn-primary">
          {id ? "Update Location" : "Save Location"}
        </button>
      </form>
    </div>
  );
}

export default LocationsForm;
