import React from "react";
import { useNavigate } from "react-router-dom";

function Slogan() {
  const navigate = useNavigate();

  const handleGetStarted = () => {
    navigate("/projects");
  };
  return (
    <div className="slogan">
      <div className="welcome">
        <div className="welcome-to">WELCOME TO</div>
        <div className="storypath">StoryPath</div>
      </div>
      <div className="get-started">
        <button className="btn btn-primary" onClick={handleGetStarted}>
          Get Started
        </button>
      </div>
    </div>
  );
}

export default Slogan;
