// generated from chatGPT 4o - used to know how react qr code work
import React from "react";
import { useLocation } from "react-router-dom";
import QRCode from "react-qr-code";

function QRCodeGenerator() {
  const location = useLocation();
  const { locations, singleLocation } = location.state || {};

  return (
    <div className="container">
      {/* depends on what user click, all QR codes or single QR code */}
      {singleLocation ? (
        <div className="card my-3">
          <div className="card-body text-center">
            <h5 className="card-title">{singleLocation.location_name}</h5>
            <QRCode value={singleLocation.location_name} size={150} />
          </div>
        </div>
      ) : (
        locations.map((location) => (
          <div className="card my-3" key={location.id}>
            <div className="card-body text-center">
              <h5 className="card-title">{location.location_name}</h5>
              <QRCode value={location.location_name} size={150} />
            </div>
          </div>
        ))
      )}
    </div>
  );
}

export default QRCodeGenerator;
