import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { getProjects, deleteProject } from "../api/ProjectApi";

const ProjectsList = () => {
  const [projects, setProjects] = useState([]); // list of projects
  const [loading, setLoading] = useState(true); // loading state
  const [error, setError] = useState(null); // store error message
  const navigate = useNavigate();

  // fetch all projects
  useEffect(() => {
    const fetchProjects = async () => {
      try {
        const projectList = await getProjects();
        setProjects(projectList); // update the projects list
      } catch (err) {
        setError("Failed to fetch projects. Please try again later.");
      } finally {
        setLoading(false);
      }
    };
    fetchProjects();
  }, []); // empty dependency array ensures this only runs once on component mount

  //  delete a project
  const handleDelete = async (id) => {
    try {
      if (window.confirm("Are you sure you want to delete this project?")) {
        await deleteProject(id);
        // remove deleted project from the list
        setProjects(projects.filter((project) => project.id !== id));
      }
    } catch (err) {
      setError("Failed to delete the project. Please try again.");
    }
  };

  // navigating to the project edit page
  const handleEdit = (id) => {
    // navigating to edit page with the project ID
    navigate(`/projects/edit/${id}`);
  };

  // navigating to add a new project
  const handleAdd = () => {
    navigate("/projects/new");
  };

  return (
    <div className="container mt-4">
      <div className="row">
        <div className="col-md-8">
          <h2 className="project-list-title">Projects List</h2>

          {/* Display loading message */}
          {loading && <p>Loading projects...</p>}

          {/* If no projects, display message */}
          {projects.length === 0 && !loading && (
            <p>No projects available. You can add a new project.</p>
          )}

          {/* Display list of projects */}
          {projects.length > 0 && (
            <ul className="list-group">
              {projects.map((project) => (
                <li className="list-group-item" key={project.id}>
                  <div className="d-flex justify-content-between align-items-center">
                    <div
                      className="project-list-description"
                      style={{ maxWidth: "65%" }}
                    >
                      <h5 className="mb-1">
                        {project.title}{" "}
                        {project.is_published && (
                          <span
                            className="badge bg-success"
                            style={{ marginLeft: "10px" }}
                          >
                            Published
                          </span>
                        )}
                      </h5>
                      <p className="mb-1">{project.description}</p>
                    </div>
                    <div>
                      <button
                        className="btn btn-primary me-2"
                        onClick={() => handleEdit(project.id)}
                        style={{ backgroundColor: "#c4adae", border: "none" }}
                      >
                        Edit
                      </button>
                      <button
                        className="btn btn-info me-2"
                        onClick={() =>
                          navigate(`/projects/${project.id}/locations`)
                        }
                        style={{
                          backgroundColor: "#c4adae",
                          border: "none",
                          color: "white",
                        }}
                      >
                        View Locations
                      </button>
                      <button
                        className="btn btn-danger"
                        onClick={() => handleDelete(project.id)}
                        style={{ backgroundColor: "#c4adae", border: "none" }}
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}

          {/* Button to add a new project */}
          <button
            className="btn btn-success mt-4"
            onClick={handleAdd}
            style={{ backgroundColor: "#6b9394", border: "none" }}
          >
            Add New Project
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProjectsList;
