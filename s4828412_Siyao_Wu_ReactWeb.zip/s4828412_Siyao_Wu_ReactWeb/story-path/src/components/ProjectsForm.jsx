import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { getProject, createProject, updateProject } from "../api/ProjectApi";

const ProjectsForm = () => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [instructions, setInstructions] = useState("");
  const [initial_clue, setinitial_clue] = useState("");
  const [homescreen_display, sethomescreen_display] = useState(
    "Display initial clue"
  );
  const [participant_scoring, setparticipant_scoring] = useState(
    "Number of Scanned QR Codes"
  );
  const [is_published, setPublished] = useState(false);
  const [error, setError] = useState(null); // store error message
  const { id } = useParams(); // get project ID from the URL
  const navigate = useNavigate();

  // fetch project details if editing an existing project
  useEffect(() => {
    if (id) {
      const fetchProject = async () => {
        try {
          const [project] = await getProject(id); // returns an array
          if (project) {
            setTitle(project.title);
            setDescription(project.description);
            setInstructions(project.instructions);
            setinitial_clue(project.initial_clue || ""); // optional initial_clue
            sethomescreen_display(project.homescreen_display);
            setparticipant_scoring(project.participant_scoring);
            setPublished(project.is_published);
          } else {
            throw new Error("Project not found");
          }
        } catch (err) {
          setError(err.message); // handle error if fetching fails
        }
      };
      fetchProject();
    }
  }, [id]); // update everytime id changed

  // handling form submission for creating/updating a project
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null); // reset error before submission

    // construct the project object
    const project = {
      title,
      description,
      instructions,
      initial_clue: initial_clue || null, // send null if the field is empty (optional)
      homescreen_display,
      participant_scoring,
      is_published,
    };

    try {
      if (id) {
        // edit an existing project
        await updateProject(id, project);
      } else {
        // create a new project
        await createProject(project);
      }
      navigate("/projects"); // redirect to projects list after saving
    } catch (err) {
      setError("Failed to save the project. Please try again."); // set error if submission fails
    }
  };

  return (
    <div className="container mt-4">
      <div className="row">
        <div className="col-md-8">
          <h2 className="mb-4">{id ? "Edit" : "Add"} Project</h2>
          <form onSubmit={handleSubmit}>
            {/* Title */}
            <div className="mb-3">
              <label htmlFor="title" className="form-label">
                Title:
              </label>
              <input
                type="text"
                className="form-control"
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Enter project title"
                required
              />
              <small className="form-text text-muted">
                The name of your project.
              </small>
            </div>

            {/* Description */}
            <div className="mb-3">
              <label htmlFor="description" className="form-label">
                Description:
              </label>
              <textarea
                className="form-control"
                id="description"
                rows="3"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Provide a brief description of your project."
                required
              ></textarea>
              <small className="form-text text-muted">
                This is not displayed to participants.
              </small>
            </div>

            {/* Instructions */}
            <div className="mb-3">
              <label htmlFor="instructions" className="form-label">
                Instructions:
              </label>
              <textarea
                className="form-control"
                id="instructions"
                rows="3"
                value={instructions}
                onChange={(e) => setInstructions(e.target.value)}
                placeholder="Enter instructions for participants."
                required
              ></textarea>
              <small className="form-text text-muted">
                Instructions for participants, explaining how to engage with the
                project.
              </small>
            </div>

            {/* Initial Clue */}
            <div className="mb-3">
              <label htmlFor="initial_clue" className="form-label">
                Initial Clue:
              </label>
              <textarea
                className="form-control"
                id="initial_clue"
                rows="2"
                value={initial_clue}
                onChange={(e) => setinitial_clue(e.target.value)}
                placeholder="Enter the initial clue (optional)."
              ></textarea>
              <small className="form-text text-muted">
                The first clue to start the project. This is optional.
              </small>
            </div>

            {/* Homescreen Display */}
            <div className="mb-3">
              <label htmlFor="homescreen_display" className="form-label">
                Homescreen Display:
              </label>
              <select
                className="form-select"
                id="homescreen_display"
                value={homescreen_display}
                onChange={(e) => sethomescreen_display(e.target.value)}
              >
                <option value="Display initial clue">
                  Display initial clue
                </option>
                <option value="Display all locations">
                  Display all locations
                </option>
              </select>
              <small className="form-text text-muted">
                Choose what to display on the homescreen of the project.
              </small>
            </div>

            {/* Participant Scoring */}
            <div className="mb-3">
              <label htmlFor="participant_scoring" className="form-label">
                Participant Scoring:
              </label>
              <select
                className="form-select"
                id="participant_scoring"
                value={participant_scoring}
                onChange={(e) => setparticipant_scoring(e.target.value)}
              >
                <option value="Number of Scanned QR Codes">
                  Number of Scanned QR Codes
                </option>
                <option value="Time to Complete">Time to Complete</option>
              </select>
              <small className="form-text text-muted">
                Select how participants will be scored in this project.
              </small>
            </div>

            {/* Published Checkbox */}
            <div className="form-check mb-3">
              <input
                className="form-check-input"
                type="checkbox"
                id="is_published"
                checked={is_published}
                onChange={(e) => setPublished(e.target.checked)}
              />
              <label className="form-check-label" htmlFor="is_published">
                Published
              </label>
            </div>

            <button type="submit" className="btn btn-primary">
              Save Project
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ProjectsForm;
