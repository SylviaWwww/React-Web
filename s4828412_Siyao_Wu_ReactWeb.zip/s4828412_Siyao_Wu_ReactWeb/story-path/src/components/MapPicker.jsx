// generated from chatGPT 4o - used to know how react leaflet work
import { MapContainer, TileLayer, Marker, useMapEvents } from "react-leaflet";
import "leaflet/dist/leaflet.css";

function MapPicker({
  mapCenter,
  markerPosition,
  setMarkerPosition,
  setLocationData,
  locationData,
}) {
  // locationMarker handles map click events and updates marker position
  function LocationMarker() {
    useMapEvents({
      click(e) {
        const { lat, lng } = e.latlng; // get latitude and longitude from the clicked position
        setMarkerPosition([lat, lng]);
        setLocationData({
          ...locationData,
          location_position: `${lat.toFixed(6)},${lng.toFixed(6)}`,
        });
      },
    });

    // if markerPosition is not null, render a marker at the clicked location
    return markerPosition === null ? null : (
      <Marker position={markerPosition}></Marker>
    );
  }

  return (
    <MapContainer
      center={mapCenter}
      zoom={13}
      style={{ height: "300px", width: "100%" }}
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      <LocationMarker />
    </MapContainer>
  );
}

export default MapPicker;
