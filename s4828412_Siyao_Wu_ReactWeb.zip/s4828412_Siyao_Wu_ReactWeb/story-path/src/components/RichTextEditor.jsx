// generated from chatGPT 4o - used to know how react quill work
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";

function RichTextEditor({ value, onChange }) {
  // define the toolbar options for the text editor
  const toolbarOptions = [
    [{ font: [] }, { size: [] }],
    ["bold", "italic", "underline", "strike"],
    [{ color: [] }, { background: [] }],
    [{ script: "sub" }, { script: "super" }],
    ["blockquote", "code-block"],
    [{ header: 1 }, { header: 2 }, { header: 3 }, { header: 4 }],
    [{ list: "ordered" }, { list: "bullet" }],
    [{ indent: "-1" }, { indent: "+1" }],
    [{ align: [] }],
    ["link", "image", "video"],
    ["clean"],
  ];

  // define the modules configuration, including the toolbar
  const modules = {
    toolbar: toolbarOptions,
    clipboard: {
      matchVisual: false,
    },
  };

  return (
    <ReactQuill
      theme="snow" // Use the 'snow' theme for the editor
      value={value}
      onChange={onChange}
      modules={modules}
      placeholder="Provide additional content that will be displayed when participants reach this location."
    />
  );
}

export default RichTextEditor;
