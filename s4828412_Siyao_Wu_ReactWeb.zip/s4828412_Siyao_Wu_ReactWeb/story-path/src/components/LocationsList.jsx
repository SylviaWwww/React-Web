import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  getLocationsByProject,
  deleteLocation,
} from "../api/LocationApi";
import { getProject } from "../api/ProjectApi";

function LocationsList() {
  const [locations, setLocations] = useState([]);
  const [projectTitle, setProjectTitle] = useState("");
  const navigate = useNavigate();
  const { projectId } = useParams(); // get id from the url
  const [error, setError] = useState(""); // store error message

  // fetch the locations
  useEffect(() => {
    async function fetchLocations() {
      try {
        const locationsData = await getLocationsByProject(projectId);
        // sort the location based on order
        const sortedLocations = locationsData.sort(
          (a, b) => a.location_order - b.location_order
        );
        setLocations(sortedLocations);
      } catch (err) {
        setError("Failed to fetch locations. Please try again later.");
      }
    }

    async function fetchProjectTitle() {
      try {
        const projectData = await getProject(projectId);
        setProjectTitle(projectData[0].title);
      } catch (err) {
        setError("Failed to fetch project details. Please try again later.");
      }
    }

    fetchLocations();
    fetchProjectTitle();
  }, [projectId]);

  // deleting location by id
  const handleDelete = async (id) => {
    try {
      await deleteLocation(id);
      setLocations(locations.filter((location) => location.id !== id));
    } catch (err) {
      setError("Failed to delete location. Please try again later.");
    }
  };

  const handleAddLocation = () => {
    navigate(`/projects/${projectId}/locations/new`);
  };

  const handleEdit = (id) => {
    navigate(`/projects/${projectId}/locations/edit/${id}`);
  };

  const handlePrintQRCode = (singleLocation) => {
    navigate(`/projects/${projectId}/locations/print-qrcode`, {
      state: { singleLocation },
    });
  };

  const handlePrintAllQRCodes = () => {
    navigate(`/projects/${projectId}/locations/print-all-qrcodes`, {
      state: { locations },
    });
  };

  const handlePreview = () => {
    navigate(`/projects/${projectId}/locations/preview`);
  };

  return (
    <div className="container">
      <h1 className="location-list-title">{projectTitle} - Locations</h1>
      <button
        className="btn btn-primary"
        onClick={handleAddLocation}
        style={{ backgroundColor: "#c4adae", border: "none" }}
      >
        Add Location
      </button>
      <button
        className="btn btn-success"
        style={{
          marginLeft: "10px",
          backgroundColor: "#c4adae",
          border: "none",
        }}
        onClick={handlePrintAllQRCodes}
      >
        Print QR Codes for All
      </button>
      <button
        className="btn btn-warning"
        style={{
          marginLeft: "10px",
          backgroundColor: "#c4adae",
          border: "none",
          color: "white",
        }}
        onClick={handlePreview}
      >
        Preview
      </button>

      {locations.map((location) => (
        <div className="card my-3" key={location.id}>
          <div className="card-body">
            <h5 className="card-title">{location.location_name}</h5>
            <p className="card-text">Trigger: {location.location_trigger}</p>
            <p className="card-text">Position: {location.location_position}</p>
            <p className="card-text">Points: {location.score_points}</p>

            <div className="d-flex justify-content-between">
              <div>
                <button
                  className="btn btn-secondary"
                  onClick={() => handleEdit(location.id)}
                  style={{ backgroundColor: "#6b9394", border: "none" }}
                >
                  Edit
                </button>
                <button
                  className="btn btn-danger mx-2"
                  onClick={() => handleDelete(location.id)}
                  style={{ backgroundColor: "#6b9394", border: "none" }}
                >
                  Delete
                </button>
                <button
                  className="btn btn-warning"
                  onClick={() => handlePrintQRCode(location)}
                  style={{
                    backgroundColor: "#6b9394",
                    border: "none",
                    color: "white",
                  }}
                >
                  Print QR Code
                </button>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

export default LocationsList;
