import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Header from "./components/layout/Header";
import Footer from "./components/layout/Footer";
import Slogan from "./components/Slogan";
import ProjectsList from "./components/ProjectsList";
import ProjectsForm from "./components/ProjectsForm";
import LocationsList from "./components/LocationsList";
import LocationsForm from "./components/LocationsForm";
import QRCodeGenerator from "./components/QRCodeGenerator";
import PreviewPage from "./components/PreviewPage";

function App() {
  return (
    <Router>
      <div className="App">
        <Header />
        <Routes>
          <Route path="/" element={<Slogan />} />
          <Route path="/projects" element={<ProjectsList />} />
          <Route path="/projects/new" element={<ProjectsForm />} />
          <Route path="/projects/edit/:id" element={<ProjectsForm />} />

          {/* Locations Routes */}
          <Route
            path="/projects/:projectId/locations"
            element={<LocationsList />}
          />
          <Route
            path="/projects/:projectId/locations/new"
            element={<LocationsForm />}
          />
          <Route
            path="/projects/:projectId/locations/edit/:id"
            element={<LocationsForm />}
          />

          {/* Generate QR Code */}
          <Route
            path="/projects/:projectId/locations/print-qrcode"
            element={<QRCodeGenerator singleLocation={true} />}
          />
          <Route
            path="/projects/:projectId/locations/print-all-qrcodes"
            element={<QRCodeGenerator singleLocation={false} />}
          />

          {/* Preview Page */}
          <Route
            path="/projects/:projectId/locations/preview"
            element={<PreviewPage />}
          />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
